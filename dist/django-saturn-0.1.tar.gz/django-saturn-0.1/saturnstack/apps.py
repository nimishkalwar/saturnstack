from django.apps import AppConfig


class SaturnstackConfig(AppConfig):
    name = 'saturnstack'
